package com.example.codigomorse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodigoMorseApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodigoMorseApplication.class, args);
    }

}
