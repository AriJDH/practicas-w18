package com.example.testcase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
