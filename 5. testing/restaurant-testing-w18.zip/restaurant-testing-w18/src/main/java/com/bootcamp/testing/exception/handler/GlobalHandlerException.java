package com.bootcamp.testing.exception.handler;

import com.bootcamp.testing.dto.ErrorDTO;
import com.bootcamp.testing.dto.ExceptionDTO;
import com.bootcamp.testing.exception.notfound.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@ControllerAdvice
public class GlobalHandlerException {

    @ExceptionHandler(NotFoundException.class)
    ResponseEntity<ExceptionDTO> recipeNotFoundException ( NotFoundException ex ) {

        ExceptionDTO exceptionDTO = new ExceptionDTO();
        exceptionDTO.setException(ex.getException());
        exceptionDTO.setStatus(ex.getStatus());
        exceptionDTO.setMessageException(ex.getMessage());

        return new ResponseEntity<>(exceptionDTO, ex.getStatus());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ErrorDTO> validatingDataTypes (
      MethodArgumentNotValidException exception
    ) {
        ErrorDTO errorDTO = new ErrorDTO();
        errorDTO.setName("Payload's Field Not Valid Exception");
        errorDTO.setMessage("There are some fields that don't respect validations");

        HashMap<String, List<String>> errors = new HashMap<>();

        exception
          .getFieldErrors()
          .forEach(
            e -> {
                String       field       = e.getField();
                String       msg         = e.getDefaultMessage();
                List<String> errorFields = new ArrayList<>();
                if (errors.containsKey(e.getField())) {
                    errorFields = errors.get(field);
                }
                errorFields.add(msg);
                errors.put(field, errorFields);
            }
          );
        errorDTO.setErrorFields(errors);
        return new ResponseEntity<>(errorDTO, HttpStatus.BAD_REQUEST);
    }

}
