package com.bootcamp.testing.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IngredientRecipeDTO {
    private String name;
    private int quantity;
}
