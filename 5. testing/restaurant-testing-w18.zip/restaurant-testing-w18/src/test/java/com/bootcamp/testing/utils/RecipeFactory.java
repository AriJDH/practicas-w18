package com.bootcamp.testing.utils;

import com.bootcamp.testing.model.Ingredient;
import com.bootcamp.testing.model.Recipe;

import java.util.ArrayList;
import java.util.List;

import static com.bootcamp.testing.utils.IngredientFactory.getIngredient;

public class RecipeFactory {
    public static Recipe getRecipe(String name){
        Recipe recipe = new Recipe();
        recipe.setName(name);
        recipe.setDescription("a");
        List<Ingredient> ingredients = new ArrayList<>();

        Ingredient ingredient1 = getIngredient("i1", 3);
        Ingredient ingredient2 = getIngredient("i2", 7);
        ingredients.add(ingredient1);
        ingredients.add(ingredient2);
        recipe.setIngredients(ingredients);
        return recipe;
    }
}
