package com.bootcamp.testing.unit.repository;

import com.bootcamp.testing.model.Ingredient;
import com.bootcamp.testing.repository.StorehouseRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Optional;

public class StorehouseRepositoryTest {

    StorehouseRepository repository = new StorehouseRepository();

    @Test
    @DisplayName("Encontramos un ingrediente que existe")
    void test1(){
        // Arrange
        String nameIngredient = "manzana";
        // Act
        Optional<Ingredient> result = repository.getIngredient(nameIngredient);
        // Assert
        Assertions.assertTrue(result.isPresent());
    }

    @Test
    @DisplayName("No Encontramos un ingrediente que no existe")
    void test2(){
        // Arrange
        String nameIngredient = "not found";
        // Act
        Optional<Ingredient> result = repository.getIngredient(nameIngredient);
        // Assert
        Assertions.assertTrue(result.isEmpty());
    }
}
