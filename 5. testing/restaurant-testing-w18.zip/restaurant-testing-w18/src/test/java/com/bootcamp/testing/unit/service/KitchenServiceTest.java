package com.bootcamp.testing.unit.service;

import com.bootcamp.testing.dto.response.DishResponseDTO;
import com.bootcamp.testing.exception.notfound.IngredientNotFoundException;
import com.bootcamp.testing.exception.notfound.RecipeNotFoundException;
import com.bootcamp.testing.model.Ingredient;
import com.bootcamp.testing.model.Recipe;
import com.bootcamp.testing.repository.interfaces.IRecipeRepository;
import com.bootcamp.testing.repository.interfaces.IStorehouseRepository;
import com.bootcamp.testing.service.KitchenService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.DoubleBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.bootcamp.testing.utils.IngredientFactory.getIngredient;
import static com.bootcamp.testing.utils.RecipeFactory.getRecipe;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class KitchenServiceTest {

    @Mock
    IRecipeRepository recipeRepository;
    @Mock
    IStorehouseRepository storehouseRepository;
    @InjectMocks
    KitchenService service;

    @Test
    @DisplayName("Calculo correcto de quality")
    void test1(){
        // Arrange
        String name = "pizza";
        Double expectedQuality = 5D;
        // Mocks
        Recipe recipe = getRecipe("name");

        Ingredient ingredient1 = getIngredient("i1", 3);
        Ingredient ingredient2 = getIngredient("i2", 7);
        // Mock
        when(recipeRepository.getRecipe(name)).thenReturn(Optional.of(recipe));
        when(storehouseRepository.getIngredient(ingredient1.getName())).thenReturn(Optional.of(ingredient1));
        when(storehouseRepository.getIngredient(ingredient2.getName())).thenReturn(Optional.of(ingredient2));
        // Act
        DishResponseDTO result = service.createDish(name);
        // Assert
        assertEquals(expectedQuality, result.getQuality());
    }

    @Test
    void test2(){
        // Arrange
        String name = "not found";
        // Mock
        when(recipeRepository.getRecipe(name)).thenReturn(Optional.empty());

        // Act & Assert
        Assertions.assertThrows(RecipeNotFoundException.class, () -> service.createDish(name));
    }

    @Test
    @Disabled
    @DisplayName("Lanzamos una exception cuando no encontramos un ingrediente")
    void test3(){
        // Arrange
        String name = "not found";
        // Mock
        when(recipeRepository.getRecipe(name)).thenReturn(Optional.empty());

        // Act & Assert
        Assertions.assertThrows(IngredientNotFoundException.class, () -> service.createDish(name));
    }
}
