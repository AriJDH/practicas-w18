package com.bootcamp.testing.unit.repository;

import com.bootcamp.testing.model.Ingredient;
import com.bootcamp.testing.model.Recipe;
import com.bootcamp.testing.repository.RecipeRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RecipeRepositoryTest {

    RecipeRepository repository;

    @BeforeEach
    void setup(){
        repository = new RecipeRepository();
    }

    @Test
    void test2(){
        // Arrange
        Recipe recipe = new Recipe();
        recipe.setName("demo");
        recipe.setDescription("demo description");
        recipe.setIngredients(new ArrayList<>());
        // Act
        Recipe result = repository.createRecipe(recipe);
        // Assert

        Assertions.assertEquals(recipe, result);
/*        Assertions.assertAll(
          () -> Assertions.assertEquals("recipe", result.getName()),
          () -> Assertions.assertEquals(5, repository.getRecipes().size())
        );*/
    }

    @Test
    void test3(){
        // Arrange
        int expectQuantity = 3;
        // Act
        List<Recipe> result = repository.getRecipes();
        // Assert
        Assertions.assertEquals(expectQuantity, result.size());
    }

}
