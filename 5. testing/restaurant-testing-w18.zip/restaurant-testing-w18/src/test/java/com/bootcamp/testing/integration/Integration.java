package com.bootcamp.testing.integration;

import com.bootcamp.testing.dto.request.RecipeDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@AutoConfigureMockMvc
@SpringBootTest
public class Integration {

    @Autowired
    MockMvc mockMvc;

    @Test
    void test1 () throws Exception {
        // Arrange
        RecipeDTO recipeDTO = new RecipeDTO();
        recipeDTO.setName("Burrito");
        recipeDTO.setDescription("Muy rico");
        recipeDTO.setIngredients(new ArrayList<>());

        RecipeDTO recipeDTO2 = new RecipeDTO();
        recipeDTO2.setName("Taco");
        recipeDTO2.setDescription("Rico");
        recipeDTO2.setIngredients(new ArrayList<>());

        String recipeJson = new ObjectMapper().writeValueAsString(recipeDTO);
        String payload = new ObjectMapper().writeValueAsString(recipeDTO);

        /* Matchers */
        ResultMatcher expectedStatus = MockMvcResultMatchers.status().isCreated();
        ResultMatcher expectedJson   = MockMvcResultMatchers.content().json(recipeJson);
        ResultMatcher expectedContentType = MockMvcResultMatchers
          .content()
          .contentType(MediaType.APPLICATION_JSON);
        /* Request */
        MockHttpServletRequestBuilder requestPayload = MockMvcRequestBuilders
                .post("/recipes/recipe")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);
        // Act & Assert
        mockMvc
          .perform(requestPayload)
          .andDo(print())
          .andExpectAll(expectedStatus, expectedJson, expectedContentType);
    }
//    @PostMapping("/recipe")
//    public RecipeDTO createRecipe( @RequestBody RecipeDTO recipeDTO){
//        return kitchenService.createRecipe(recipeDTO);
//    }
}
