package com.sports.sports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
