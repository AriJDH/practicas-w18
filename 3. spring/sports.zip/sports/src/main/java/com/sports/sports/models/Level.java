package com.sports.sports.models;

public enum Level {
    Amateur,
    SemiPro,
    Pro
}
