package com.ejerciciospring.ejercicios_spring.practica2_dto_response.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Deporte {

    private String nombre;

    private String nivel;

}
