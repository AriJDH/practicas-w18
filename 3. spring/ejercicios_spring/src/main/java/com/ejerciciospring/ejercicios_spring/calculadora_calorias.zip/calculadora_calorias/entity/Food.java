package com.ejerciciospring.ejercicios_spring.calculadora_calorias.entity;

import lombok.Data;

@Data
public class Food {

    private String name;

    private Integer calories;

}
