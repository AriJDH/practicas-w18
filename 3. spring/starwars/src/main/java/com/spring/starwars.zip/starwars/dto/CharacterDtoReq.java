package com.spring.starwars.dto;

public class CharacterDtoReq {
}
