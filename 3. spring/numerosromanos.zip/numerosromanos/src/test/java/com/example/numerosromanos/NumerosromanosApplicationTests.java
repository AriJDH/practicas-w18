package com.example.numerosromanos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumerosromanosApplicationTests {

	@Test
	void contextLoads() {
	}

}
