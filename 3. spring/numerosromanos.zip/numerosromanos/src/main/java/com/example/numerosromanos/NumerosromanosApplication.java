package com.example.numerosromanos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumerosromanosApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumerosromanosApplication.class, args);
	}


}
