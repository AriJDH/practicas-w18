package com.example.demo_calculadora_calorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCalculadoraCaloriasApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoCalculadoraCaloriasApplication.class, args);
    }

}
