package com.example.demo_calculadora_calorias.dto.response;

import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EstructuraPlatoDtores {
    private String name;
    private Integer calories;
}
