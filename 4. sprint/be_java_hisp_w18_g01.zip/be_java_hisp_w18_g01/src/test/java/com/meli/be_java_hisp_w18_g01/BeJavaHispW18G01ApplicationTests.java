package com.meli.be_java_hisp_w18_g01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeJavaHispW18G01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
