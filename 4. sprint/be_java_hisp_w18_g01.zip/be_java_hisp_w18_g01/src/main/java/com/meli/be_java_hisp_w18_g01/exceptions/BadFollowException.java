package com.meli.be_java_hisp_w18_g01.exceptions;

public class BadFollowException extends RuntimeException{
    public BadFollowException(String message){
        super(message);
    }
}
