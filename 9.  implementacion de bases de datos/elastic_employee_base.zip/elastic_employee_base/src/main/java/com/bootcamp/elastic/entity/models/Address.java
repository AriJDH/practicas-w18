package com.bootcamp.elastic.entity.models;

import lombok.Data;

@Data
public class Address {
    String city;
    String direction;
}
