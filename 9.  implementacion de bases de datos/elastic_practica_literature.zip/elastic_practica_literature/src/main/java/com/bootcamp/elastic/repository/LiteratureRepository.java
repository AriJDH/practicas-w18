package com.bootcamp.elastic.repository;

import com.bootcamp.elastic.entity.Literature;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface LiteratureRepository {
/*    @Override
    List<Literature> findAll();*/
}
