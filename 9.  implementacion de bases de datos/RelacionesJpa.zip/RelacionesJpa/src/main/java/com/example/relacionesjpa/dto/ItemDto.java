package com.example.relacionesjpa.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ItemDto {
    private String description;
}
