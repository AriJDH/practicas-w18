package com.example.empresadeseguros.service;

import com.example.empresadeseguros.dto.response.ListPatMarcaVehiculosDTOResponse;
import com.example.empresadeseguros.dto.response.PatentesVehiculosDTOResponse;
import com.example.empresadeseguros.repository.IRepositoryVehiculo;

public interface IServiceVehiculo {
    PatentesVehiculosDTOResponse findAllVehiculos();
    ListPatMarcaVehiculosDTOResponse findAllVehiculosOrderbyAnio();
}
