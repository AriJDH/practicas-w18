package com.example.empresadeseguros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpresaDeSegurosApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmpresaDeSegurosApplication.class, args);
    }

}
