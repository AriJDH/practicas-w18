package com.example.empresadeseguros.service;

import com.example.empresadeseguros.dto.response.ListPatMarcaVehiculosDTOResponse;
import com.example.empresadeseguros.dto.response.PatMarcaVehiculosDTOResponse;
import com.example.empresadeseguros.dto.response.PatentesVehiculosDTOResponse;
import com.example.empresadeseguros.entity.Vehiculo;
import com.example.empresadeseguros.repository.IRepositorySiniestro;
import com.example.empresadeseguros.repository.IRepositoryVehiculo;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ServiceVehiculoImp implements IServiceVehiculo{
    private final IRepositoryVehiculo iRepositoryVehiculo;

    public ServiceVehiculoImp(IRepositoryVehiculo iRepositoryVehiculo){
        this.iRepositoryVehiculo = iRepositoryVehiculo;
    }
    @Override
    public PatentesVehiculosDTOResponse findAllVehiculos() {
        List<String> listPatentes = iRepositoryVehiculo.findAllVehiculos().stream().map(x->x.getPatente()).collect(Collectors.toList());
        PatentesVehiculosDTOResponse patentesVehiculosDTOResponse = new PatentesVehiculosDTOResponse();
        patentesVehiculosDTOResponse.setPatente(listPatentes);
        patentesVehiculosDTOResponse.setMensaje("Listado de patentes de vehículos registrados.");
        return patentesVehiculosDTOResponse;
    }

    @Override
    public ListPatMarcaVehiculosDTOResponse findAllVehiculosOrderbyAnio() {
        List<PatMarcaVehiculosDTOResponse> listMarcaPatentes = iRepositoryVehiculo.findAllVehiculosOrderbyAnio()
                .stream()
                .map(x-> new PatMarcaVehiculosDTOResponse(x.getMarca(), x.getPatente()))
                .collect(Collectors.toList());
        ListPatMarcaVehiculosDTOResponse listPatMarcaVehiculosDTOResponse = new ListPatMarcaVehiculosDTOResponse();
        listPatMarcaVehiculosDTOResponse.setPatenteMarca(listMarcaPatentes);
        listPatMarcaVehiculosDTOResponse.setMensaje("Listado de marcas y patentes de vehículos ordenados por año de fabricación.");
        return listPatMarcaVehiculosDTOResponse;
    }
}

