package com.example.empresadeseguros.entity;

import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Setter
@Entity
@Table(name = "siniestros")
public class Siniestro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private LocalDate fecha;
    private Double perdidaEconomica;

}

