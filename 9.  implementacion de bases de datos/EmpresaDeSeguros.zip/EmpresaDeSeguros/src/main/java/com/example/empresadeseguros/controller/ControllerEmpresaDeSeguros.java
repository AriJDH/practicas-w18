package com.example.empresadeseguros.controller;

import com.example.empresadeseguros.dto.response.ListPatMarcaVehiculosDTOResponse;
import com.example.empresadeseguros.dto.response.PatentesVehiculosDTOResponse;
import com.example.empresadeseguros.service.IServiceVehiculo;
import com.example.empresadeseguros.service.ServiceVehiculoImp;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerEmpresaDeSeguros {

    private final IServiceVehiculo iServiceVehiculo;

    public ControllerEmpresaDeSeguros(ServiceVehiculoImp serviceVehiculoImp){
        this.iServiceVehiculo = serviceVehiculoImp;
    }

    @GetMapping("/AllPatentes")
    public ResponseEntity<PatentesVehiculosDTOResponse> findAllVehiculos(){
        return new ResponseEntity<>(iServiceVehiculo.findAllVehiculos(), HttpStatus.OK);
    }

    @GetMapping("/AllPatentesByAnio")
    public ResponseEntity<ListPatMarcaVehiculosDTOResponse> findAllVehiculosOrderbyAnio(){
        return new ResponseEntity<>(iServiceVehiculo.findAllVehiculosOrderbyAnio(), HttpStatus.OK);
    }

}
