package com.example.empresadeseguros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpresaDeSegurosApplicationTests {

    @Test
    void contextLoads() {
    }

}
